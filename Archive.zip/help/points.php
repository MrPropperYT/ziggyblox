<?php
// Initialize the session
session_start();
require_once "../config.php";
  ini_set('display_errors', 0);
?>

<head>
    <meta charset="UTF-8">
    <title>ZiggyBlocks Points</title>
    <link rel="stylesheet" type="text/css" href="/Roblox.css">
</head>

<table cellspacing="0" cellpadding="0" width="950">
  <tbody><tr>
    <td style="BORDER-RIGHT: black 1px solid; PADDING-RIGHT: 8px; PADDING-LEFT: 8px; PADDING-BOTTOM: 8px; PADDING-TOP: 8px" bgcolor="lightsteelblue" colspan="2" class="Header">
      <span id="_ctl0_Span1" style="PADDING-RIGHT: 4px; FLOAT: left; TEXT-ALIGN: left" class="Header">
            <img  src="/images/roblox_logo.png"  alt="" width="160" height="21"  />
      </span>
      <span id="_ctl0_LabelSlogan" class="Header">The Online Construction Toy</span><span style="PADDING-RIGHT: 4px; FLOAT: right; TEXT-ALIGN: right" class="Header">
      <?php
  if(isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] == true){
    $id = $_SESSION['id'];
    $sql="SELECT * FROM users where id='$id'";
    $data = mysqli_query($link, $sql);
    $row = mysqli_fetch_array($data);
    echo "Welcome, " . $_SESSION["username"] . "&nbsp|&nbsp<font color='blue'>ZP</font>&nbsp:&nbsp" . $row["points"];
  }
        ?>
      </span></td>
  </tr>
  <tr>
    <td valign="top" width="118">
      <div style="BORDER-RIGHT: black 1px solid; PADDING-RIGHT: 8px; PADDING-LEFT: 8px; PADDING-BOTTOM: 8px; PADDING-TOP: 0px; BORDER-BOTTOM: black 1px solid; BACKGROUND-COLOR: lightsteelblue">
        <a id="_ctl0_HyperlinkHome" class="MenuItem" href="/default.php">Home</a><br>
        <a id="_ctl0_HyperLinkBuild" class="MenuItem" href="/build.php">Build!</a><br>
        <a id="_ctl0_Hyperlink12" class="MenuItem" href="/levels.php">Games</a><br>
        <a id="_ctl0_HyperLink9" class="MenuItem" href="/models.php">Models</a><br>
        <a id="_ctl0_Hyperlink3" class="MenuItem" href="/contests/default.php">Contests</a><br>
        <a id="_ctl0_Hyperlink6" class="MenuItem" href="/my/default.php">My Stuff</a><br>
        <a id="_ctl0_HyperLink10" class="MenuItem" href="/community.php">People</a><br>
        <a id="_ctl0_HyperLink11" class="MenuItem" href="https://discord.gg/GgdCwH7xWj">Discord</a><br>
        <table id="_ctl0_PanelSignIn" cellpadding="0" cellspacing="0" border="0" width="100%"><tbody><tr><td>
          <a id="_ctl0_Hyperlink8" class="MenuItem" href="/login.php">Sign In</a>
          <br>
</td></tr></tbody></table><table id="_ctl0_PanelSignOut" cellpadding="0" cellspacing="0" border="0" width="100%"><tbody><tr><td>
          <a id="_ctl0_HyperLinkSignOut" class="MenuItem" href="/logout.php">Sign Out</a>
          <br>
        
</td></tr></tbody></table>
        <a id="_ctl0_Hyperlink2" class="MenuItem" href="/help/default.php">FAQ</a>
        <br>
        <br>
<span style="WIDTH: 112px; PADDING-TOP: 1em">
          <table id="_ctl0_TopPointHolders1_DataList1" cellspacing="0" cellpadding="3" rules="rows" bordercolor="#E7E7FF" border="1" bgcolor="White" width="100%">
  <tbody><tr>
    <td bgcolor="#4A3C8C"><font color="#F7F7F7"><b>
    Top Points Holders</b></font></td>
      <?php
  $sql = "SELECT * FROM users ORDER BY points DESC LIMIT 10";
  $altColor = false;
  
      if($result = mysqli_query($link, $sql)){
          if(mysqli_num_rows($result) > 0){
              while($row = mysqli_fetch_array($result)){
                  echo "<tr>";
                  if ($altColor == false){
                    echo "<td bgcolor='#E7E7FF'><font color='#4A3C8C'><span style='FLOAT: left'><a href='/users.php?id=". $row['id'] . "'>" . $row['username'] . "</a></span><span style='FLOAT: right'><span>" . $row['points'] . "</span></span></font></td></tr>";
                    $altColor = true;
                  }
                  else{
                    echo "<td bgcolor='#F7F7F7'><font color='#4A3C8C'><span style='FLOAT: left'><a href='/users.php?id=". $row['id'] . "'>" . $row['username'] . "</a></span><span style='FLOAT: right'><span>" . $row['points'] . "</span></span></font></td></tr>";
                    $altColor = false;
                  }
              }
              // Free result set
              mysqli_free_result($result);
          } else{
              echo "No records matching your query were found.";
          }
      } else{
          echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
      }

      // Close connection
      mysqli_close($link);
  ?>
  </tbody></table></span>
                </div>
    </td>
    <td style="BORDER-TOP: black 1px solid; PADDING-LEFT: 8px; PADDING-TOP: 8px" valign="top">
      <h1 class="Title" align="center">ZiggyBlocks Points</h1>
      <ul>
      <li class="MsoCommentSubject">What are ZiggyBlocks points?</li>
      <li class="MsoToc2">ZiggyBlocks points are a system of displaying your skill on ZiggyBlocks. People with higher amounts of points are considered more skillful at minigames.</li>
      <br>
      <li class="MsoCommentSubject">How do I earn ZiggyBlocks points?</li>
      <li class="MsoToc2">You can earn ZiggyBlocks points by creating a popular minigame, winning a contest, suggesting a feature that gets considered or reporting bugs.</li>
      <br>
      <li class="MsoCommentSubject">How do I tell how many points I have?</li>
      <li class="MsoToc2">Next to your name at the top of every webpage on the site is your ZiggyBlocks points total.</li>
      <br>
      <li class="MsoCommentSubject">How do I tell who has the most points?</li>
      <li class="MsoToc2">On the left side of the page is a scoreboard that shows the top 10 highest ranked users. If you wish to see more, you can filter the user search on the community page by points.</li>
      <br>
      </ul>
    </td>
  </tr>
  <tr>
    <td></td>
    <td style="PADDING-LEFT: 8px; PADDING-TOP: 12px">
<hr>
<div class="Legal" style="TEXT-ALIGN: center">ZiggyBlocks is not affiliated with the Roblox Corporation or the Godot Engine. ZiggyBlocks is not made for profit. Anyone trying to sell this software or is passing it off as an "authentic" 2005 Roblox client is a scammer and should be reported.</div></td></tr>
</tbody>
</table>