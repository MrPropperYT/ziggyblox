<?php
// Initialize the session
session_start();
require_once "config.php";
ini_set('display_errors', 0);
?>


<head>
    <meta charset="UTF-8">
    <title>Welcome to ZiggyBlocks!</title>
    <link rel="stylesheet" type="text/css" href="/Roblox.css">
</head>

<table cellspacing="0" cellpadding="0" width="950">
  <tbody><tr>
    <td style="BORDER-RIGHT: black 1px solid; PADDING-RIGHT: 8px; PADDING-LEFT: 8px; PADDING-BOTTOM: 8px; PADDING-TOP: 8px" bgcolor="lightsteelblue" colspan="2" class="Header">
      <span id="_ctl0_Span1" style="PADDING-RIGHT: 4px; FLOAT: left; TEXT-ALIGN: left" class="Header">
            <img  src="/images/roblox_logo.png"  alt="" width="160" height="21"  />
      </span>
      <span id="_ctl0_LabelSlogan" class="Header">The Online Construction Toy</span><span style="PADDING-RIGHT: 4px; FLOAT: right; TEXT-ALIGN: right" class="Header">
      <?php
  if(isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] == true){
    $id = $_SESSION['id'];
    $sql="SELECT * FROM users where id='$id'";
    $data = mysqli_query($link, $sql);
    $row = mysqli_fetch_array($data);
    echo "Welcome, " . $_SESSION["username"] . "&nbsp|&nbsp<font color='blue'>ZP</font>&nbsp:&nbsp" . $row["points"];
  }
        ?>
      </span></td>
  </tr>
  <tr>
    <td valign="top" width="118">
      <div style="BORDER-RIGHT: black 1px solid; PADDING-RIGHT: 8px; PADDING-LEFT: 8px; PADDING-BOTTOM: 8px; PADDING-TOP: 0px; BORDER-BOTTOM: black 1px solid; BACKGROUND-COLOR: lightsteelblue">
        <a id="_ctl0_HyperlinkHome" class="MenuItem" href="/default.php">Home</a><br>
        <a id="_ctl0_HyperLinkBuild" class="MenuItem" href="/build.php">Build!</a><br>
        <a id="_ctl0_Hyperlink12" class="MenuItem" href="/levels.php">Games</a><br>
        <a id="_ctl0_HyperLink9" class="MenuItem" href="/models.php">Models</a><br>
        <a id="_ctl0_Hyperlink3" class="MenuItem" href="/contests/default.php">Contests</a><br>
        <a id="_ctl0_Hyperlink6" class="MenuItem" href="/my/default.php">My Stuff</a><br>
        <a id="_ctl0_HyperLink10" class="MenuItem" href="/community.php">People</a><br>
        <a id="_ctl0_HyperLink11" class="MenuItem" href="https://discord.gg/GgdCwH7xWj">Discord</a><br>
        <table id="_ctl0_PanelSignIn" cellpadding="0" cellspacing="0" border="0" width="100%"><tbody><tr><td>
          <a id="_ctl0_Hyperlink8" class="MenuItem" href="/login.php">Sign In</a>
          <br>
</td></tr></tbody></table><table id="_ctl0_PanelSignOut" cellpadding="0" cellspacing="0" border="0" width="100%"><tbody><tr><td>
          <a id="_ctl0_HyperLinkSignOut" class="MenuItem" href="/logout.php">Sign Out</a>
          <br>
        
</td></tr></tbody></table>
        <a id="_ctl0_Hyperlink2" class="MenuItem" href="/help/default.php">FAQ</a>
        <br>
        <br>
<span style="WIDTH: 112px; PADDING-TOP: 1em">
          <table id="_ctl0_TopPointHolders1_DataList1" cellspacing="0" cellpadding="3" rules="rows" bordercolor="#E7E7FF" border="1" bgcolor="White" width="100%">
  <tbody><tr>
    <td bgcolor="#4A3C8C"><font color="#F7F7F7"><b>
    Top Points Holders</b></font></td>
      <?php
  $sql = "SELECT * FROM users ORDER BY points DESC LIMIT 10";
  $altColor = false;
  
      if($result = mysqli_query($link, $sql)){
          if(mysqli_num_rows($result) > 0){
              while($row = mysqli_fetch_array($result)){
                  echo "<tr>";
                  if ($altColor == false){
                    echo "<td bgcolor='#E7E7FF'><font color='#4A3C8C'><span style='FLOAT: left'><a href='/users.php?id=". $row['id'] . "'>" . $row['username'] . "</a></span><span style='FLOAT: right'><span>" . $row['points'] . "</span></span></font></td></tr>";
                    $altColor = true;
                  }
                  else{
                    echo "<td bgcolor='#F7F7F7'><font color='#4A3C8C'><span style='FLOAT: left'><a href='/users.php?id=". $row['id'] . "'>" . $row['username'] . "</a></span><span style='FLOAT: right'><span>" . $row['points'] . "</span></span></font></td></tr>";
                    $altColor = false;
                  }
              }
              // Free result set
              mysqli_free_result($result);
          } else{
              echo "No records matching your query were found.";
          }
      } else{
          echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
      }

      // Close connection
      //mysqli_close($link);
  ?>
  </tbody></table></span>
                </div>
        
    </td>
    <td style="BORDER-TOP: black 1px solid; PADDING-LEFT: 8px; PADDING-TOP: 8px">
      <div style="TEXT-ALIGN: center">
        <img id="_ctl0_ImageTitle" src="/web/20050624075917im_/http://www.roblox.com/images/roblox_logo.png" alt="" border="0">
        
        <p></p>
      </div>
      
      <table style="FLOAT: left; MARGIN-BOTTOM: 5px; MARGIN-RIGHT: 5px; TEXT-ALIGN: right" id="Table1">
        <tbody><tr>
          <td>
            <table id="_ctl0_DatalistGetStarted" cellspacing="2" cellpadding="3" rules="all" bordercolor="#DEBA84" border="1" bgcolor="#DEBA84" width="130">
  <tbody><tr>
    <td bgcolor="#A55129"><font color="White"><b>
                Get Started
              </b></font></td>
  </tr><tr>
    <td align="Center" bgcolor="#FFF7E7"><font color="#8C4510">
                <a id="_ctl0_DatalistGetStarted__ctl1_Contentimage5" title="Untitled" href="#" style="cursor:hand;"><img src="/images/Level.png" border="0" width="105" height="70"></a><br>
                <a id="_ctl0_DatalistGetStarted__ctl1_Hyperlink5" href="#">Untitled</a>
              </font></td>
  </tr><tr>
    <td align="Center" bgcolor="#FFF7E7"><font color="#8C4510">
                <a id="_ctl0_DatalistGetStarted__ctl1_Contentimage5" title="Untitled" href="#" style="cursor:hand;"><img src="/images/Level.png" border="0" width="105" height="70"></a><br>
                <a id="_ctl0_DatalistGetStarted__ctl1_Hyperlink5" href="#">Untitled</a>
              </font></td>
  </tr><tr>
    <td align="Center" bgcolor="#FFF7E7"><font color="#8C4510">
                <a id="_ctl0_DatalistGetStarted__ctl1_Contentimage5" title="Untitled" href="#" style="cursor:hand;"><img src="/images/Level.png" border="0" width="105" height="70"></a><br>
                <a id="_ctl0_DatalistGetStarted__ctl1_Hyperlink5" href="#">Untitled</a>
              </font></td>
  </tr><tr>
    <td align="Center" bgcolor="#FFF7E7"><font color="#8C4510">
                <a id="_ctl0_DatalistGetStarted__ctl1_Contentimage5" title="Untitled" href="#" style="cursor:hand;"><img src="/images/Level.png" border="0" width="105" height="70"></a><br>
                <a id="_ctl0_DatalistGetStarted__ctl1_Hyperlink5" href="#">Untitled</a>
              </font></td>
  </tr><tr>
    <td align="Center" bgcolor="#FFF7E7"><font color="#8C4510">
                <a id="_ctl0_DatalistGetStarted__ctl1_Contentimage5" title="Untitled" href="#" style="cursor:hand;"><img src="/images/Level.png" border="0" width="105" height="70"></a><br>
                <a id="_ctl0_DatalistGetStarted__ctl1_Hyperlink5" href="#">Untitled</a>
              </font></td>
  </tr><tr>
    <td align="Center" bgcolor="#FFF7E7"><font color="#8C4510">
                <a id="_ctl0_DatalistGetStarted__ctl1_Contentimage5" title="Untitled" href="#" style="cursor:hand;"><img src="/images/Level.png" border="0" width="105" height="70"></a><br>
                <a id="_ctl0_DatalistGetStarted__ctl1_Hyperlink5" href="#">Untitled</a>
              </font></td>
  </tr><tr>
    <td align="Center" bgcolor="#FFF7E7"><font color="#8C4510">
                <a id="_ctl0_DatalistGetStarted__ctl1_Contentimage5" title="Untitled" href="#" style="cursor:hand;"><img src="/images/Level.png" border="0" width="105" height="70"></a><br>
                <a id="_ctl0_DatalistGetStarted__ctl1_Hyperlink5" href="#">Untitled</a>
              </font></td>
  </tr>
</tbody></table></td>
        </tr>
        <tr>
          <td></td>
        </tr>
        <tr>
          <td>
            </td>
        </tr>
      </tbody></table>
      <table id="Table2" style="FLOAT: right; MARGIN-BOTTOM: 5px; MARGIN-LEFT: 5px; TEXT-ALIGN: right">
        <tbody><tr>
          <td><table id="_ctl0_DatalistTopGames" cellspacing="2" cellpadding="4" rules="all" bordercolor="#999999" border="3" bgcolor="#CCCCCC" width="130">
  <tbody><tr>
    <td bgcolor="Black"><font color="White"><b>
                Top Games
              </b></font></td>
  </tr><tr>
    <td align="Center" bgcolor="White"><font color="Black">
                <a id="_ctl0_DatalistTopGames__ctl1_ContentImage1" title="Untitled" href="#" style="cursor:hand;"><img src="/images/Level.png" border="0" width="90" height="50"></a><br>
                <a id="_ctl0_DatalistTopGames__ctl1_HyperLink2" href="#">Untitled</a>
              </font></td>
  </tr><tr>
    <td align="Center" bgcolor="White"><font color="Black">
                <a id="_ctl0_DatalistTopGames__ctl1_ContentImage1" title="Untitled" href="#" style="cursor:hand;"><img src="/images/Level.png" border="0" width="90" height="50"></a><br>
                <a id="_ctl0_DatalistTopGames__ctl1_HyperLink2" href="#">Untitled</a>
              </font></td>
  </tr><tr>
    <td align="Center" bgcolor="White"><font color="Black">
                <a id="_ctl0_DatalistTopGames__ctl1_ContentImage1" title="Untitled" href="#" style="cursor:hand;"><img src="/images/Level.png" border="0" width="90" height="50"></a><br>
                <a id="_ctl0_DatalistTopGames__ctl1_HyperLink2" href="#">Untitled</a>
              </font></td>
  </tr><tr>
    <td align="Center" bgcolor="White"><font color="Black">
                <a id="_ctl0_DatalistTopGames__ctl1_ContentImage1" title="Untitled" href="#" style="cursor:hand;"><img src="/images/Level.png" border="0" width="90" height="50"></a><br>
                <a id="_ctl0_DatalistTopGames__ctl1_HyperLink2" href="#">Untitled</a>
              </font></td>
  </tr><tr>
    <td align="Center" bgcolor="White"><font color="Black">
                <a id="_ctl0_DatalistTopGames__ctl1_ContentImage1" title="Untitled" href="#" style="cursor:hand;"><img src="/images/Level.png" border="0" width="90" height="50"></a><br>
                <a id="_ctl0_DatalistTopGames__ctl1_HyperLink2" href="#">Untitled</a>
              </font></td>
  </tr>
</tbody></table></td>
        </tr>
        <tr>
          <td></td>
        </tr>
        <tr>
          <td>
            <table id="_ctl0_DatalistNewStuff" cellspacing="0" cellpadding="4" rules="all" bordercolor="#CC9966" border="1" bgcolor="White" width="130">
  <tbody><tr>
    <td bgcolor="#990000"><font color="#FFFFCC"><b>
                New Stuff
              </b></font></td>
  </tr>
  <?php
  //<tr><td align="Center" bgcolor="#FFCC99"><font color="#CC99CC"><b>
  //<a id="_ctl0_DatalistNewStuff__ctl1_ContentImage7" title="Untitled" href="#" style="cursor:hand;"><img src="/images/Level.png" border="0" width="105" height="70"></a><br>
  //<a id="_ctl0_DatalistNewStuff__ctl1_HyperLink6" href="#">Untitled</a>
  //</b></font></td></tr>
  //<tr><td bgcolor="White"><font color="#330099">
  //<a id="_ctl0_DatalistNewStuff__ctl2_HyperLink3" href="#">Untitled</a>
  //</font></td></tr>
  // The two templates.
  $sql = "SELECT * FROM games ORDER BY created DESC LIMIT 6";
  $isFirst = true;
    if($result = mysqli_query($link, $sql)){
          if(mysqli_num_rows($result) > 0){
              while($row = mysqli_fetch_array($result)){
        if ($isFirst) {
          echo '<tr><td align="Center" bgcolor="#FFCC99"><font color="#CC99CC"><b>';
          echo '<a id="_ctl0_DatalistNewStuff__ctl1_ContentImage7" title="' . $row["title"] . '" href="/game?id=' . $row["id"] . '" style="cursor:hand;"><img src="/' . $row["thumbnail"] . '" border="0" width="105" height="70"></a><br>';
          echo '<a id="newstuffhhh" href="/game?id=' . $row["id"] . '">' . $row["title"] . '</a>';
          echo '</b></font></td></tr>';
          $isFirst = false;
        } else {
          echo '<tr><td bgcolor="White"><font color="#330099">';
          echo '<a id="newstuffhhh" href="/game?id=' . $row["id"] . '">' . $row["title"] . '</a>';
          echo '</font></td></tr>';
        }
        }
        mysqli_free_result($result);
      } else {
        echo "No games.";
      }
    } else {
     echo "Failed to load."; 
    }
  ?>
</tbody></table>
          </td>
        </tr>
      </tbody></table>
      <table style="BORDER-RIGHT: black thin solid; BORDER-TOP: black thin solid; MARGIN-BOTTOM: 12px; BORDER-LEFT: black thin solid; BORDER-BOTTOM: black thin solid" cellspacing="0" cellpadding="5">
        <tbody><tr>
          <td style="FONT-WEIGHT: bold; COLOR: white" bgcolor="steelblue">News</td>
        </tr>
        <tr>
          <td>
            <p>
              
</p>
<?php
$sql = "SELECT * FROM news ORDER BY posted DESC LIMIT 2";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_array($result)){
      echo '<p><strong>' . $row['posted'] . ':</strong> ' . $row['contents'] . '</p>';
    }
    mysqli_free_result($result);
  }
} else {
  echo "Oops! Something went wrong.";
}

// okay now we end sql's existance
// Dear Donovan,
//     You MORON, you messed up ONE WORD!
//  "okay now we end sql's existance"
//                              ^
//  YOU MESSED UP THE A YOU DUMB-
//  -Donovan
//mysqli_close($link);

?>
<p></p>
            <p>
              <a id="_ctl0_HyperLink1" href="/news.php">More...</a></p>
          </td>
        </tr>
      </tbody></table>
      

      <br>
      Welcome to ZiggyBlocks! With your help, we have built a community of members with a 
      passion for building, inventing and playing! Best of all, it's completely FREE! 
      With ZiggyBlocks, you can…
      <h1>Invent!</h1>
            If you can imagine it, you can build it (see how it works) on ZiggyBlocks! Build 
      vehicles, characters, buildings or whatever you want with the ZiggyBlocks pieces.
      <h1>Play ZiggyBlocks!</h1>
      Play lots of cool games, all built by the ZiggyBlocks community. Find a game to 
      match your interest. Compete for high score and ZiggyBlocks points.
      <h1>Build ZiggyBlocks!</h1>
      <a href="/build.php">Build your own games</a> to 
      earn even more ZiggyBlocks points. You can build puzzles, driving games, 
      construction games – use your imagination and show your work to your friends!
      <h1>Earn <a href="/help/points.php">ZiggyBlocks Points!</a></h1>
      <p>Everything you do on ZiggyBlocks earns ZiggyBlocks points. Publish a popular game or get 
        high score to earn LOTS of points.</p>
      <p align="center">
        <br>
        Try ZiggyBlocks today. It's free!</p>
    </td>
  </tr>
  <tr>
    <td></td>
    <td style="PADDING-LEFT: 8px; PADDING-TOP: 12px">
<hr>
<div class="Legal" style="TEXT-ALIGN: center">ZiggyBlocks is not affiliated with the Roblox Corporation or the Godot Engine. ZiggyBlocks is not made for profit. Anyone trying to sell this software or is passing it off as an "authentic" 2005 Roblox client is a scammer and should be reported.</div></td></tr>
</tbody>
</table>
<?php
mysqli_close($link);
?>