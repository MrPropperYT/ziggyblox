<?php


$file = file_get_contents('http://GodoRevivalThumbnailGen.pythonanywhere.com/?' . $_SERVER['QUERY_STRING']); // Can be locally too, for example: something.php
echo $file;
?>