<head>
    <meta charset="UTF-8">
    <title>Welcome to ZiggyBlocks!</title>
    <link rel="stylesheet" type="text/css" href="/Roblox.css">
</head>

<table style="border-right: black 1px solid; padding-right: 8px; padding-left: 8px; background-color: lightsteelblue" width=658px; height=34px>
<tbody>
<tr>
<td class="header">&#8205; <img  src="/images/roblox_logo.png"  alt="" width="160" height="21"  /> The Online Construction Toy</td>
  <td class="header"><?php echo "Welcome," + $_SESSION["username"]; ?></td>
</tr>
</tbody>
</table>
<table>
<tbody>
<tr>
<td style="border-right: black 1px solid; padding-left: 8px; padding-bottom: 8px; border-bottom: black 1px solid; background-color: lightsteelblue; border-top: lightsteelblue 1px solid" width=118px; height=722px; valign="top">
  <a href="https://ZiggyBlocks.ct8.pl/default.php"><p class="menuitem">Home</p></a>
  <a href="https://ZiggyBlocks.ct8.pl/build.php"><p class="menuitem">Build!</p></a>
  <a href="https://ZiggyBlocks.ct8.pl/games.php"><p class="menuitem">Games</p></a>
  <a href="https://ZiggyBlocks.ct8.pl/models.php"><p class="menuitem">Models</p></a>
  <a href="https://ZiggyBlocks.ct8.pl/contests.php"><p class="menuitem">Contests</p></a>
  <a href="https://ZiggyBlocks.ct8.pl/my/default.php"><p class="menuitem">My Stuff</p></a>
  <a href="https://ZiggyBlocks.ct8.pl/people.php"><p class="menuitem">People</p></a>
  <a href="https://discord.gg/GgdCwH7xWj"><p class="menuitem">Discord</p></a>
  <a href="https://ZiggyBlocks.ct8.pl/login.php"><p class="menuitem">Sign In</p></a>
  <a href="https://ZiggyBlocks.ct8.pl/logout.php"><p class="menuitem">Sign Out</p></a>
  <a href="https://ZiggyBlocks.ct8.pl/faq.php"><p class="menuitem">FAQ</p></a>
  </td>
<td style="border-top: black 1px solid;" width=755px; valign="top">
  
  </td>
</tr>
</tbody>
</table>
