<?php
  ini_set('display_errors', 0);
session_start();
require_once "../config.php";
if (isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] == true) {
  echo $_FILES['userfile']['name'];
  $level_to_upload = file_get_contents($_FILES['userfile']['tmp_name']);
  //echo $level_to_upload;
    if (strlen($_POST["title"]) < 20) {
        if ($_POST["wasprev"] == false) {
            $sql = "INSERT INTO games (thumbnail, title, creator, description, contents, username) VALUES ('images/Level.png','" . $_POST["title"] . "'," . $_SESSION["id"] . ",'" . $_POST["description"] . "','" . $level_to_upload . "','" . $_SESSION["username"] . "');";
        } else {
            $sql = "INSERT INTO games (thumbnail, title, creator, description, contents, username, created) VALUES ('images/Level.png','" . $_POST["title"] . "'," . $_SESSION["id"] . ",\"" . $_POST["description"] . "\",'" . $level_to_upload . "','" . $_SESSION["username"] . "','" . $_POST["uploadts"] . "');";
        }
        if (mysqli_query($link,$sql)) {
            echo "Success.";
            header("location: /my/default.php");
        } else {
            echo "Mission failed.";
        }
    } else {
        echo "Please go back and fix your game's title. Sorry! It was too long. Max. 20 chars";
    }
  mysqli_close($link);
} else {
  echo "<script>window.location.href = '/login.php';</script>";
}

?>
