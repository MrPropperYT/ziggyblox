<?php
// Initialize the session
header('Content-Type: image/png');
ini_set('display_errors', 0);
session_start();
$game = "blank";
require_once "config.php";

      $sql = "SELECT contents FROM games WHERE id=" . $_GET["gid"];
  
      if($result = mysqli_query($link, $sql)){
          if(mysqli_num_rows($result) > 0){
              while($row = mysqli_fetch_array($result)){
                  $game = $row["contents"];
              }
              // Free result set
              mysqli_free_result($result);
          }
      }


$file = file_get_contents('http://GodoRevivalThumbnailGen.pythonanywhere.com/?size=' . $_GET["size"] . '&game=' . urlencode($game)); // Can be locally too, for example: something.php
echo $file;


mysqli_close($link);
?>
