<?php
$servername = "mysql2.serv00.com";
$username = "m9729_vapor";
$password = "Chen294135";

// Create connection
$link = new mysqli($servername, $username, $password,"m9729_roblox2009");
?>

