<?php
// Initialize the session
session_start();
require_once "../config.php";
ini_set('display_errors', 0);

if($_SERVER["REQUEST_METHOD"] == "POST"){
  if ($_SESSION["loggedin"]) {
    if ($_SESSION["isAdmin"] > 1) {
      $sql = "UPDATE games SET created='" . $_POST["timestamp"] .  "' WHERE id=" . $_POST["gameid"];
      //echo $sql;
      mysqli_query($link,$sql);
      header("location: /my/default.php");
    } else {
      echo "This action cannot be performed unless you are an admin or the game owner.";
    }
  } else {
    echo "This action cannot be performed unless you are an admin or the game owner.";
  }
}

?>