<?php
// Initialize the session
session_start();
require_once "config.php";
ini_set('display_errors', 0);
?>

<head>
    <meta charset="UTF-8">
    <title>ZiggyBlocks People</title>
    <link rel="stylesheet" type="text/css" href="/Roblox.css">
</head>

<table cellspacing="0" cellpadding="0" width="950">
  <tbody><tr>
    <td style="BORDER-RIGHT: black 1px solid; PADDING-RIGHT: 8px; PADDING-LEFT: 8px; PADDING-BOTTOM: 8px; PADDING-TOP: 8px" bgcolor="lightsteelblue" colspan="2" class="Header">
      <span id="_ctl0_Span1" style="PADDING-RIGHT: 4px; FLOAT: left; TEXT-ALIGN: left" class="Header">
            <img  src="/images/roblox_logo.png"  alt="" width="160" height="21"  />
      </span>
      <span id="_ctl0_LabelSlogan" class="Header">The Online Construction Toy</span><span style="PADDING-RIGHT: 4px; FLOAT: right; TEXT-ALIGN: right" class="Header">
      <?php
  if(isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] == true){
    $id = $_SESSION['id'];
    $sql="SELECT * FROM users where id='$id'";
    $data = mysqli_query($link, $sql);
    $row = mysqli_fetch_array($data);
    echo "Welcome, " . $_SESSION["username"] . "&nbsp|&nbsp<font color='blue'>ZP</font>&nbsp:&nbsp" . $row["points"];
  }
        ?>
      </span></td>
  </tr>
  <tr>
    <td valign="top" width="118">
      <div style="BORDER-RIGHT: black 1px solid; PADDING-RIGHT: 8px; PADDING-LEFT: 8px; PADDING-BOTTOM: 8px; PADDING-TOP: 0px; BORDER-BOTTOM: black 1px solid; BACKGROUND-COLOR: lightsteelblue">
        <a id="_ctl0_HyperlinkHome" class="MenuItem" href="/default.php">Home</a><br>
        <a id="_ctl0_HyperLinkBuild" class="MenuItem" href="/build.php">Build!</a><br>
        <a id="_ctl0_Hyperlink12" class="MenuItem" href="/levels.php">Games</a><br>
        <a id="_ctl0_HyperLink9" class="MenuItem" href="/models.php">Models</a><br>
        <a id="_ctl0_Hyperlink3" class="MenuItem" href="/contests/default.php">Contests</a><br>
        <a id="_ctl0_Hyperlink6" class="MenuItem" href="/my/default.php">My Stuff</a><br>
        <a id="_ctl0_HyperLink10" class="MenuItem" href="/community.php">People</a><br>
        <a id="_ctl0_HyperLink11" class="MenuItem" href="https://discord.gg/GgdCwH7xWj">Discord</a><br>
        <table id="_ctl0_PanelSignIn" cellpadding="0" cellspacing="0" border="0" width="100%"><tbody><tr><td>
          <a id="_ctl0_Hyperlink8" class="MenuItem" href="/login.php">Sign In</a>
          <br>
</td></tr></tbody></table><table id="_ctl0_PanelSignOut" cellpadding="0" cellspacing="0" border="0" width="100%"><tbody><tr><td>
          <a id="_ctl0_HyperLinkSignOut" class="MenuItem" href="/logout.php">Sign Out</a>
          <br>
        
</td></tr></tbody></table>
        <a id="_ctl0_Hyperlink2" class="MenuItem" href="/help/default.php">FAQ</a>
        <br>
        <br>
<span style="WIDTH: 112px; PADDING-TOP: 1em">
          <table id="_ctl0_TopPointHolders1_DataList1" cellspacing="0" cellpadding="3" rules="rows" bordercolor="#E7E7FF" border="1" bgcolor="White" width="100%">
  <tbody><tr>
    <td bgcolor="#4A3C8C"><font color="#F7F7F7"><b>
    Top Points Holders</b></font></td>
      <?php
  $sql = "SELECT * FROM users ORDER BY points DESC LIMIT 10";
  $altColor = false;
  
      if($result = mysqli_query($link, $sql)){
          if(mysqli_num_rows($result) > 0){
              while($row = mysqli_fetch_array($result)){
                  echo "<tr>";
                  if ($altColor == false){
                    echo "<td bgcolor='#E7E7FF'><font color='#4A3C8C'><span style='FLOAT: left'><a href='/users.php?id=". $row['id'] . "'>" . $row['username'] . "</a></span><span style='FLOAT: right'><span>" . $row['points'] . "</span></span></font></td></tr>";
                    $altColor = true;
                  }
                  else{
                    echo "<td bgcolor='#F7F7F7'><font color='#4A3C8C'><span style='FLOAT: left'><a href='/users.php?id=". $row['id'] . "'>" . $row['username'] . "</a></span><span style='FLOAT: right'><span>" . $row['points'] . "</span></span></font></td></tr>";
                    $altColor = false;
                  }
              }
              // Free result set
              mysqli_free_result($result);
          } else{
              echo "No records matching your query were found.";
          }
      } else{
          echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
      }

      // Close connection
      //mysqli_close($link);
  ?>
  </tbody></table></span>
                </div>
    </td>
    <td style="BORDER-TOP: black 1px solid; PADDING-LEFT: 8px; PADDING-TOP: 8px" valign="top">
    <h3>List of ZiggyBlocks users from oldest to newest.</h3>
      Users listed <select name="showing" id="showing">
        <option value="?show=25">25</option>
        <option value="?show=50">50</option>
        <option value="?show=100">100</option>
        <option value="?show=200">200</option>
        <option value="?show=9999999999">All</option>
      </select>&nbsp; &nbsp;
      <input id="searching" placeholder="Enter a username to refine your search." size="32">
      &nbsp;&nbsp;Sort by <select name="sorting" id="sorting">
        <option value="&amp;sort=id">User ID</option>
        <option value="&amp;sort=username">Username</option>
        <option value="&amp;sort=points">Points</option>
      </select>
      <button id="searchBtn" onclick="onClick()">Search</button>
      <script>
        
        var input = document.getElementById("searching");
        input.addEventListener("keypress", function(event) {
          if (event.key === "Enter") {
            event.preventDefault();
            document.getElementById("searchBtn").click();
          }
        });
        
        function onClick() {
          var x = document.getElementById("showing").value;
          var y = document.getElementById("sorting").value;
          var z = document.getElementById("searching").value;
          window.location.href = "/community.php" + x + y + "&search=" + z;
        }
      </script>
      <br>
      <br>
      <table style="BORDER-RIGHT: black thin solid; BORDER-TOP: black thin solid; MARGIN-BOTTOM: 12px; BORDER-LEFT: black thin solid;" width="818" cellspacing="0" cellpadding="5">
              <tbody>
        <tr>
                <td style="FONT-WEIGHT: bold; COLOR: white; border-right: black 1px solid; border-bottom: black 1px solid;" bgcolor="steelblue">&nbsp;User ID&nbsp;</td>
                <td style="FONT-WEIGHT: bold; COLOR: white; border-right: black 1px solid; border-bottom: black 1px solid;" bgcolor="steelblue">Username</td>
                <td style="FONT-WEIGHT: bold; COLOR: white; border-right: black 1px solid; border-bottom: black 1px solid;" bgcolor="steelblue">Points</td>
                <td style="FONT-WEIGHT: bold; COLOR: white; border-bottom: black 1px solid;" bgcolor="steelblue">Date Created</td>
              </tr>
    <?php
    if ($_GET["sort"] == null) {
      echo "<script>window.location.href = '/community.php?show=25&sort=id&search='</script>";
    }
    // add the sql code
    $sql = "SELECT * FROM users ORDER BY " . $_GET["sort"] . " ASC LIMIT " . $_GET["show"];
    if($result = mysqli_query($link, $sql)){
          if(mysqli_num_rows($result) > 0){
              while($row = mysqli_fetch_array($result)){
                  if (str_contains($row["username"],$_GET["search"])) {
                    echo '<tr>';
                    echo '<td style="border-right: black 1px solid; border-bottom: black 1px solid;">' . $row["id"] . '</td>';
                    echo '<td style="border-right: black 1px solid; border-bottom: black 1px solid;">';
                    echo '<a href="/users.php?id=' . $row["id"] . '">' . $row["username"] . '</a>';
                    echo '</td>';
                    echo '<td style="border-right: black 1px solid; border-bottom: black 1px solid;">' . $row["points"] . '</td>';
                    echo '<td style=" border-bottom: black 1px solid;">' . $row["joined"] . '</td>';
                    echo '</tr>';
                  }
          }
          mysqli_free_result($result);
      }
    } else {
      echo "Oops! Something went wrong.";
    }
      
    // okay now we end sql's existance
    mysqli_close($link);
    ?>
  </tr></tbody></table>
  <tr>
    <td></td>
    <td style="PADDING-LEFT: 8px; PADDING-TOP: 12px">
<hr>
<div class="Legal" style="TEXT-ALIGN: center">ZiggyBlocks is not affiliated with the Roblox Corporation or the Godot Engine. ZiggyBlocks is not made for profit. Anyone trying to sell this software or is passing it off as an "authentic" 2005 Roblox client is a scammer and should be reported.</div></td></tr>
</tbody>
</table>