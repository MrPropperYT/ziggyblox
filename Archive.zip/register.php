<?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["username"]))){
        $username_err = "Username can only contain letters, numbers, and underscores.";
    } elseif(strlen(trim($_POST["username"])) > 14) {
        $username_err = "USERNAME IS TOO LONG!";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["username"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have atleast 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO users (username, password, description) VALUES (?, ?, \"This is your user description!\nYou can change this.\")";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password);
            
            // Set parameters
            $hashed_username = hash("sha256",$username);
            $hashed_password = hash("sha256",$password);
            $hashdata = hash("sha256",$hashed_username . $hashed_password);
            $param_username = $username;
            //$param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
			$param_password = $hashdata;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: login.php");
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    //mysqli_close($link);
}
?>

<?php
// Initialize the session
session_start();

?>

<head>
    <meta charset="UTF-8">
    <title>Sign up - ZiggyBlocks</title>
    <link rel="stylesheet" type="text/css" href="/Roblox.css">
</head>

<table cellspacing="0" cellpadding="0" width="950">
  <tbody><tr>
    <td style="BORDER-RIGHT: black 1px solid; PADDING-RIGHT: 8px; PADDING-LEFT: 8px; PADDING-BOTTOM: 8px; PADDING-TOP: 8px" bgcolor="lightsteelblue" colspan="2" class="Header">
      <span id="_ctl0_Span1" style="PADDING-RIGHT: 4px; FLOAT: left; TEXT-ALIGN: left" class="Header">
            <img  src="/images/roblox_logo.png"  alt="" width="160" height="21"  />
      </span>
      <span id="_ctl0_LabelSlogan" class="Header">The Online Construction Toy</span><span style="PADDING-RIGHT: 4px; FLOAT: right; TEXT-ALIGN: right" class="Header">
      <?php
  if(isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] == true){
    $id = $_SESSION['id'];
    $sql="SELECT * FROM users where id='$id'";
    $data = mysqli_query($link, $sql);
    $row = mysqli_fetch_array($data);
    echo "Welcome, " . $_SESSION["username"] . "&nbsp|&nbsp<font color='blue'>ZP</font>&nbsp:&nbsp" . $row["points"];
  }
        ?>
      </span></td>
  </tr>
  <tr>
    <td valign="top" width="118">
      <div style="BORDER-RIGHT: black 1px solid; PADDING-RIGHT: 8px; PADDING-LEFT: 8px; PADDING-BOTTOM: 8px; PADDING-TOP: 0px; BORDER-BOTTOM: black 1px solid; BACKGROUND-COLOR: lightsteelblue">
        <a id="_ctl0_HyperlinkHome" class="MenuItem" href="/default.php">Home</a><br>
        <a id="_ctl0_HyperLinkBuild" class="MenuItem" href="/build.php">Build!</a><br>
        <a id="_ctl0_Hyperlink12" class="MenuItem" href="/levels.php">Games</a><br>
        <a id="_ctl0_HyperLink9" class="MenuItem" href="/models.php">Models</a><br>
        <a id="_ctl0_Hyperlink3" class="MenuItem" href="/contests/default.php">Contests</a><br>
        <a id="_ctl0_Hyperlink6" class="MenuItem" href="/my/default.php">My Stuff</a><br>
        <a id="_ctl0_HyperLink10" class="MenuItem" href="/community.php">People</a><br>
        <a id="_ctl0_HyperLink11" class="MenuItem" href="https://discord.gg/GgdCwH7xWj">Discord</a><br>
        <table id="_ctl0_PanelSignIn" cellpadding="0" cellspacing="0" border="0" width="100%"><tbody><tr><td>
          <a id="_ctl0_Hyperlink8" class="MenuItem" href="/login.php">Sign In</a>
          <br>
</td></tr></tbody></table><table id="_ctl0_PanelSignOut" cellpadding="0" cellspacing="0" border="0" width="100%"><tbody><tr><td>
          <a id="_ctl0_HyperLinkSignOut" class="MenuItem" href="/logout.php">Sign Out</a>
          <br>
        
</td></tr></tbody></table>
        <a id="_ctl0_Hyperlink2" class="MenuItem" href="/help/default.php">FAQ</a>
        <br>
        <br>
<span style="WIDTH: 112px; PADDING-TOP: 1em">
          <table id="_ctl0_TopPointHolders1_DataList1" cellspacing="0" cellpadding="3" rules="rows" bordercolor="#E7E7FF" border="1" bgcolor="White" width="100%">
  <tbody><tr>
    <td bgcolor="#4A3C8C"><font color="#F7F7F7"><b>
    Top Points Holders</b></font></td>
      <?php
  $sql = "SELECT * FROM users ORDER BY points DESC LIMIT 10";
  $altColor = false;
  
      if($result = mysqli_query($link, $sql)){
          if(mysqli_num_rows($result) > 0){
              while($row = mysqli_fetch_array($result)){
                  echo "<tr>";
                  if ($altColor == false){
                    echo "<td bgcolor='#E7E7FF'><font color='#4A3C8C'><span style='FLOAT: left'><a href='/users.php?id=". $row['id'] . "'>" . $row['username'] . "</a></span><span style='FLOAT: right'><span>" . $row['points'] . "</span></span></font></td></tr>";
                    $altColor = true;
                  }
                  else{
                    echo "<td bgcolor='#F7F7F7'><font color='#4A3C8C'><span style='FLOAT: left'><a href='/users.php?id=". $row['id'] . "'>" . $row['username'] . "</a></span><span style='FLOAT: right'><span>" . $row['points'] . "</span></span></font></td></tr>";
                    $altColor = false;
                  }
              }
              // Free result set
              mysqli_free_result($result);
          } else{
              echo "No records matching your query were found.";
          }
      } else{
          echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
      }

      // Close connection
      mysqli_close($link);
  ?>
  </tbody></table></span>
                </div>
    </td>
    <td style="BORDER-TOP: black 1px solid; PADDING-LEFT: 8px; PADDING-TOP: 8px" valign="top">
    
    <div class="wrapper">
        <h3>Create an account for ZiggyBlocks</h3>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
            <table style="width: 360px;" >
            <tbody>
              <tr>
                <td>
                <label>Username:</label>
                </td>
                <td>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <br>
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
                </td>
                </tr>
            </div>    
            <br>
            <div class="form-group" style="width:240px;">
              <tr>
                <td>
                <label>Password:</label>
                </td>
                <td>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>">
                <br>
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
                </td>
                </tr>
            </div>
            <br>
            <div class="form-group">
              <tr>
                <td>
                <label>Confirm Password:</label>
                </td>
                <td>
                <input type="password" name="confirm_password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $confirm_password; ?>">
                </td>
                </tr>
                </tbody>
                </table>
                <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
            </div>

            <br>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Create account">
            </div>
            <p>Already have an account? <a href="login.php">Login here</a>.</p>
        </form>
    </div>    
    
    </td>
  </tr>
  <tr>
    <td></td>
    <td style="PADDING-LEFT: 8px; PADDING-TOP: 12px">
<hr>
<div class="Legal" style="TEXT-ALIGN: center">ZiggyBlocks is not affiliated with the Roblox Corporation or the Godot Engine. ZiggyBlocks is not made for profit. Anyone trying to sell this software or is passing it off as an "authentic" 2005 Roblox client is a scammer and should be reported.</div></td></tr>
</tbody>
</table>

