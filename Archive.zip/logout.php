<?php
session_start();
$_SESSION["loggedin"] = null;
$_SESSION["id"] = null;
$_SESSION["username"] = null;
$_SESSION["isAdmin"] = null;
?>
<script>window.location.href = "/default.php";</script><?php
session_start();
$_SESSION["loggedin"] = null;
$_SESSION["id"] = null;
$_SESSION["username"] = null;
$_SESSION["isAdmin"] = null;
?>
<script>window.location.href = "/default.php";</script><?php
session_start();
$_SESSION["loggedin"] = null;
$_SESSION["id"] = null;
$_SESSION["username"] = null;
$_SESSION["isAdmin"] = null;
?>
<script>window.location.href = "/default.php";</script><?php
session_start();
$_SESSION["loggedin"] = null;
$_SESSION["id"] = null;
$_SESSION["username"] = null;
$_SESSION["isAdmin"] = null;
?>
<script>window.location.href = "/default.php";</script>