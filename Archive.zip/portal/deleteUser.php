<?php
ini_set('display_errors', 0);
session_start();
require_once '../config.php';
if (isset($_SESSION['loggedin'])) {
  if ($_SESSION['loggedin']) {
    echo "Login authenticated. Now checking if user is a valid admin.";
    if ($_SESSION['isAdmin'] > 0) {
      echo "User's an admin. Guess there's someone about to lose their account.";
      if ($_POST['uid'] != 1) {
        echo "";
        $sql = "DELETE FROM users WHERE id = " . $_POST['uid'];
        mysqli_query($link,$sql);
        $sql = "DELETE FROM games WHERE creator = " . $_POST['uid'];
        mysqli_query($link,$sql);
        header("location: /my/default.php");
      } else {
        echo "Can't. User's AntiGev.";
      }
    }
  } else {
    echo "Nice try.";
  }
} else {
  echo "Nice try.";
}
?>